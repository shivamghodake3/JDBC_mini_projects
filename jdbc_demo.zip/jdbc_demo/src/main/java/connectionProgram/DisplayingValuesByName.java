package connectionProgram;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

public class DisplayingValuesByName {

	public static void main(String[] args) throws ClassNotFoundException ,SQLException{
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/school","root","sql123");
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery("select * from student where name='abhishek'");
		while(rs.next()) {
			System.out.println(rs.getInt(1)+" "+rs.getInt(3)+" "+rs.getString(2));
		}
	}

}
