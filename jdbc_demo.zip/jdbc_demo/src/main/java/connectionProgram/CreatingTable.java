package connectionProgram;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class CreatingTable {

	public static void main(String[] args)throws ClassNotFoundException, SQLException {
		//1
		Class.forName("com.mysql.cj.jdbc.Driver");
		//2
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/school","root","sql123");
		//3
		Statement st=con.createStatement();
		//4
		st.execute("create table student(id integer,name varchar(25),age integer,address varchar(25))");
		System.out.println("table created..!");
		//5
		con.close();
	}

}
