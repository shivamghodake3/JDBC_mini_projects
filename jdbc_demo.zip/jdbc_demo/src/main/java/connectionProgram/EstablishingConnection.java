package connectionProgram;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class EstablishingConnection {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		 //1.load and register the driver
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		//2.establish connection
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306","root","sql123");
		System.out.println("connection established..!");
		System.out.println(con);
	}

}

