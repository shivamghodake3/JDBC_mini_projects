package connectionProgram;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class UpdatingValues {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/school","root","sql123");
		Statement st=con.createStatement();
		st.executeUpdate("update student set age=25,address='delhi' where name='mala'");
//		st.executeUpdate("delete from student where id=2");
		System.out.println("updation done..!");
		con.close();
		
	}

}
