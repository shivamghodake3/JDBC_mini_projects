package connectionProgram;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DeletingValues {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost/school","root","sql123");
		Statement st=con.createStatement();
		int rows=st.executeUpdate("delete from student where id=2");
		
		if(rows==0) {
			System.out.println("no data found");
		}
		else {
			
			System.out.println("deleted successfully..!");
		}
		con.close();
	}

}
