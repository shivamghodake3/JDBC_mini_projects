package connectionProgram;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DisplayNameAddress {

	public static void main(String[] args)throws ClassNotFoundException,SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/school","root","sql123");
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery("select name,address from student where age>20");
		while(rs.next()) {
			System.out.println(rs.getString(1)+" "+rs.getString(2));
		}
		ResultSet rs1=st.executeQuery("select age from student");
		while(rs1.next()) {
			System.out.println(rs1.getInt(1));
		}
		con.close();
	}

}
