package jdbc_dynamic_project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class UpdatingValuesDynamically {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/company","root","sql123");
		PreparedStatement ps=con.prepareStatement("update employee set salary=?,designation=? where name=?");
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter designation");
		String desig=sc.next();
		System.out.println("enter salary for designation");
		int sal=sc.nextInt();
		System.out.println("enter the name");
		String name=sc.next();
		
		ps.setInt(1, sal);
		ps.setString(2, desig);
		ps.setString(3, name);
		
		ps.executeUpdate();
		System.out.println("info updates successfully..!");
		con.close();
	}

}
