package jdbc_dynamic_project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class InsertDeleteStudentInfo {

	public static void main(String[] args)throws ClassNotFoundException,SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/advance_java","root","sql123");
//		PreparedStatement ps=con.prepareStatement("delete from student where rollno=?");
		PreparedStatement ps=con.prepareStatement("insert into student values(?,?,?,?,?,?,?)");

		Scanner sc=new Scanner(System.in);
		System.out.println("enter rollno");
		int rollno=sc.nextInt();
		
		System.out.println("enter name");
		String name=sc.next();
		
		System.out.println("enter mobile no");
		long mno=sc.nextLong();
		
		System.out.println("enter email ");
		String email=sc.next();
		
		System.out.println("enter degree ");
		String deg=sc.next();
		
		System.out.println("enter college id ");
		int cid=sc.nextInt();
		
		System.out.println("enter percentage ");
		double per=sc.nextDouble();
		
		
		ps.setInt(1, rollno);
		ps.setLong(3,mno);
		ps.setString(2, name);
		ps.setString(4, email);
		ps.setString(5, deg);
		ps.setInt(6, cid);
		ps.setDouble(7, per);
		
		ps.executeUpdate();
		con.close();
	}

}
