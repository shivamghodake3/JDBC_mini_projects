package jdbc_dynamic_project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;
public class DeletingValuesDynamically {

	public static void main(String[] args)throws ClassNotFoundException,SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/company","root","sql123");
		PreparedStatement ps=con.prepareStatement("delete from employee where salary>?");
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter sal");
		int sal=sc.nextInt();
		
		ps.setInt(1, sal);
		
		ps.executeUpdate();
		System.out.println("data deleted successfully.!!");
		con.close();
	}

}
