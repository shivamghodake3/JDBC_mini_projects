package jdbc_dynamic_project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class InsertingValuesDynamically {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/company","root","sql123");
		//create a stmt using PreparedStatement
		//create dynamic sql query using placeholder
		PreparedStatement ps=con.prepareStatement("insert into employee values(?,?,?,?)");
		//take input from user
		Scanner sc=new Scanner(System.in);
		System.out.println("enter id");
		int id=sc.nextInt();
		System.out.println("enter name");
		String name=sc.next();
		System.out.println("enter salary");
		int sal=sc.nextInt();
		System.out.println("enter designation");
		String desig=sc.next();
		
		//set the user entered values in place of place holders(question marks).
		ps.setInt(1,id);
		ps.setString(2, name);
		ps.setInt(3,sal);
		ps.setString(4, desig);
		
		//execute the query
		ps.executeUpdate();
		
		con.close();
		
		
		
	}

}
