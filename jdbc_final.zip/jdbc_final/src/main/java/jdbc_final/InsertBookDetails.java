package jdbc_final;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class InsertBookDetails {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/library","root","sql123");
		PreparedStatement ps=con.prepareStatement("insert into books values(?,?,?,?)");
		
		Scanner sc=new Scanner(System.in);
		for(int i=1;i<=5;i++) {
		System.out.println("enter bookid");
		int bid=sc.nextInt();
		System.out.println("enter book name");
		String bname=sc.next();
		System.out.println("enter book price");
		int price=sc.nextInt();
		System.out.println("enter book author name");
		String author=sc.next();
		
		ps.setInt(1, bid);
		ps.setString(2, bname);
		ps.setInt(3, price);
		ps.setString(4, author);
		ps.executeUpdate();
		System.out.println("data inserted successfully...!");
		}
		con.close();
		
	}

}
