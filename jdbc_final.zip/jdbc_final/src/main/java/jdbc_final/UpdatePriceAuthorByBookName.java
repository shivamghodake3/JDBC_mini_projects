package jdbc_final;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class UpdatePriceAuthorByBookName {

	public static void main(String[] args)throws ClassNotFoundException, SQLException  {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/library","root","sql123");
		PreparedStatement ps=con.prepareStatement("update books set price=?,author=? where name=?");
		Scanner sc=new Scanner(System.in);
	
		System.out.println("enter price");
		int price=sc.nextInt();
		
		System.out.println("enter author name");
		String author=sc.next();
		
		System.out.println("enter bookname");
		String bname=sc.next();
		
		ps.setInt(1, price);
		ps.setString(2, author);
		ps.setString(3, bname);
		
		ps.executeUpdate();
		System.out.println("price and author updated successfully of book: "+bname);
		
		con.close();
	}

}
