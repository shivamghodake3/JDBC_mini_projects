package jdbc_final;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DeleteBookByAuthorName {

	public static void main(String[] args)throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/library","root","sql123");
		Statement st=con.createStatement();
		st.executeUpdate("delete from books where author='robert'");
		System.out.println("book deleted successfuly..!");
		con.close();
	}

}
